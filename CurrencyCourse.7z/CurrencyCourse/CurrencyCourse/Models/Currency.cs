﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CurrencyCourse.Models
{
    public class Currency
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public ICollection<Rate> Rates { get; set; }
    }
}
