﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CurrencyCourse.Models
{
    public class Rate
    {
        public int RateID { get; set; }
        public int CurrencyID { get; set; }
        [DataType(DataType.Date)]
        public DateTime ChangeDate { get; set; }
        public float SellRate { get; set; }
        public float BuyRate { get; set; }

        public Rate() { }
        public Rate(float sellRate, float buyRate) : this()
        {
            SellRate = sellRate;
            BuyRate = buyRate;
        }
    }
}
