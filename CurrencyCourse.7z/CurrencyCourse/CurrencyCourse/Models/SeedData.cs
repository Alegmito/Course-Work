﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CurrencyCourse.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new CurrencyContext(
                serviceProvider.GetRequiredService<DbContextOptions<CurrencyContext>>()))
            {
                if (context.Rate.Any())
                {
                    return;
                }

                context.Currency.AddRange(

                    new Currency { Name = "Rouble" },
                    new Currency { Name = "US dollar" },
                    new Currency { Name = "Pond sterling" },
                    new Currency { Name = "Australian dollar" },
                    new Currency { Name = "Euro" },
                    new Currency { Name = "Yen" },
                    new Currency { Name = "Swiss Franc" },
                    new Currency { Name = "Indian rupee" },
                    new Currency { Name = "Sweden krona" },
                    new Currency { Name = "Mexican Peso" }
                );
                context.SaveChanges();

                context.Rate.AddRange(new Rate { SellRate = 680.56f, BuyRate = 683.23f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 1 },
                    new Rate { SellRate = 681, BuyRate = 683.98f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 1 },
                    new Rate { SellRate = 681.1f, BuyRate = 684f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 1 },
                    new Rate { SellRate = 681.6f, BuyRate = 683f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 1 },
                    new Rate { SellRate = 10.05f, BuyRate = 11f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 2 },
                    new Rate { SellRate = 10.06f, BuyRate = 10.68f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 2 },
                    new Rate { SellRate = 10f, BuyRate = 10.55f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 2 },
                    new Rate { SellRate = 10.15f, BuyRate = 10.35f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 2 },
                    new Rate { SellRate = 12.5f, BuyRate = 13.11f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 3 },
                    new Rate { SellRate = 12.45f, BuyRate = 13.19f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 3 },
                    new Rate { SellRate = 12.3f, BuyRate = 13.08f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 3 },
                    new Rate { SellRate = 12.67f, BuyRate = 14f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 3 },
                    new Rate { SellRate = 14.16f, BuyRate = 15f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 4 },
                    new Rate { SellRate = 14.88f, BuyRate = 14.68f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 4 },
                    new Rate { SellRate = 14.65f, BuyRate = 14.86f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 4 },
                    new Rate { SellRate = 14.46f, BuyRate = 14.48f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 4 },
                    new Rate { SellRate = 8.71f, BuyRate = 8.68f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 5 },
                    new Rate { SellRate = 8.68f, BuyRate = 8.64f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 5 },
                    new Rate { SellRate = 8.64f, BuyRate = 8.66f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 5 },
                    new Rate { SellRate = 8.59f, BuyRate = 8.13f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 5 },
                    new Rate { SellRate = 1070.86f, BuyRate = 1080.13f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 6 },
                    new Rate { SellRate = 1060.59f, BuyRate = 1069.46f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 6 },
                    new Rate { SellRate = 1065.89f, BuyRate = 1063.43f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 6 },
                    new Rate { SellRate = 1064.53f, BuyRate = 1060.13f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 6 },
                    new Rate { SellRate = 9.85f, BuyRate = 10.01f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 7 },
                    new Rate { SellRate = 9.80f, BuyRate = 9.89f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 7 },
                    new Rate { SellRate = 9.46f, BuyRate = 9.54f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 7 },
                    new Rate { SellRate = 9.55f, BuyRate = 9.50f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 7 },
                    new Rate { SellRate = 701.03f, BuyRate = 702.35f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 8 },
                    new Rate { SellRate = 701.13f, BuyRate = 702.34f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 8 },
                    new Rate { SellRate = 700.08f, BuyRate = 701.77f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 8 },
                    new Rate { SellRate = 699.68f, BuyRate = 700.76f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 8 },
                    new Rate { SellRate = 89.23f, BuyRate = 90.13f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 9 },
                    new Rate { SellRate = 89.64f, BuyRate = 89.68f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 9 },
                    new Rate { SellRate = 89.46f, BuyRate = 89.79f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 9 },
                    new Rate { SellRate = 88.99f, BuyRate = 89.25f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 9 },
                    new Rate { SellRate = 194.34f, BuyRate = 190.45f, ChangeDate = DateTime.Parse("2018-06-01"), CurrencyID = 10 },
                    new Rate { SellRate = 193.49f, BuyRate = 191.88f, ChangeDate = DateTime.Parse("2018-06-02"), CurrencyID = 10 },
                    new Rate { SellRate = 192.36f, BuyRate = 192.79f, ChangeDate = DateTime.Parse("2018-06-03"), CurrencyID = 10 },
                    new Rate { SellRate = 193.06f, BuyRate = 181.56f, ChangeDate = DateTime.Parse("2018-06-04"), CurrencyID = 10 });
                context.SaveChanges();
            }
        }
            
    }
}
