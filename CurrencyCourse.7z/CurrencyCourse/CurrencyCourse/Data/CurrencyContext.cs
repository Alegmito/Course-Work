﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace CurrencyCourse.Models
{
    public class CurrencyContext : DbContext
    {
        public CurrencyContext (DbContextOptions<CurrencyContext> options)
            : base(options)
        {
        }

        public DbSet<Rate> Rate { get; set; }
        public DbSet<Currency> Currency { get; set; }
    }
}
